# Flap Bird Clone

## Overview
This project is a clone of the famous Flappy Bird game. The game is built using HTML, CSS, and JavaScript, and it aims to replicate the original game's mechanics and aesthetics.

## Files Structure
- **index.html**: The main entry point of the game. It sets up the HTML structure, includes the CSS for styling, and links the JavaScript files necessary for game functionality.
- **css/styles.css**: Contains the styles for the game, including layout, colors, fonts, and animations to enhance the visual appeal.
- **js/game.js**: Responsible for the main game logic, including initializing the game, handling user input (like jumping), updating the game state, and rendering the game on the canvas.
- **js/bird.js**: Defines the Bird class, which includes properties such as position and velocity, and methods for updating the bird's position and rendering it on the canvas.
- **js/pipes.js**: Defines the Pipes class, which manages the creation and movement of the pipes that the bird must navigate through. It includes methods for generating pipes, updating their position, and checking for collisions with the bird.

## How to Run the Game
1. Clone the repository or download the files.
2. Open `index.html` in your web browser.
3. Use the spacebar or click to make the bird jump.

## Controls
- **Spacebar**: Make the bird jump.
- **Mouse Click**: Make the bird jump.

## Features
- Simple and intuitive controls.
- Endless gameplay with increasing difficulty.
- Collision detection with pipes and ground.
- Score tracking.

## Acknowledgments
This project is inspired by the original Flappy Bird game and aims to provide a similar experience. Enjoy playing!