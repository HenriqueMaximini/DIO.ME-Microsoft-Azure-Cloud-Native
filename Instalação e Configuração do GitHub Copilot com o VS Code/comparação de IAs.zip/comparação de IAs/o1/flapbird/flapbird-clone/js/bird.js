class Bird {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 34; // Width of the bird image
        this.height = 24; // Height of the bird image
        this.gravity = 0.6; // Gravity effect
        this.lift = -15; // Lift effect when jumping
        this.velocity = 0; // Initial velocity
        this.image = new Image();
        this.image.src = 'path/to/bird-image.png'; // Path to the bird image
    }

    update() {
        this.velocity += this.gravity; // Apply gravity
        this.y += this.velocity; // Update position based on velocity

        // Prevent the bird from falling below the canvas
        if (this.y + this.height >= canvas.height) {
            this.y = canvas.height - this.height;
            this.velocity = 0; // Reset velocity
        }

        // Prevent the bird from flying above the canvas
        if (this.y < 0) {
            this.y = 0;
            this.velocity = 0; // Reset velocity
        }
    }

    jump() {
        this.velocity += this.lift; // Apply lift when jumping
    }

    render(ctx) {
        ctx.drawImage(this.image, this.x, this.y, this.width, this.height); // Draw the bird on the canvas
    }
}