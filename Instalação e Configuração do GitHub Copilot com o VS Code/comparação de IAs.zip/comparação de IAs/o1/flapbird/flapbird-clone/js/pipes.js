class Pipe {
    constructor(x, width, gap) {
        this.x = x;
        this.width = width;
        this.gap = gap;
        this.height = Math.floor(Math.random() * (canvas.height - gap));
    }

    update(speed) {
        this.x -= speed;
    }

    draw(ctx) {
        ctx.fillStyle = 'green';
        ctx.fillRect(this.x, 0, this.width, this.height); // Top pipe
        ctx.fillRect(this.x, this.height + this.gap, this.width, canvas.height); // Bottom pipe
    }

    isOffScreen() {
        return this.x + this.width < 0;
    }

    checkCollision(bird) {
        if (bird.x + bird.width > this.x && bird.x < this.x + this.width) {
            if (bird.y < this.height || bird.y + bird.height > this.height + this.gap) {
                return true;
            }
        }
        return false;
    }
}

class PipeManager {
    constructor() {
        this.pipes = [];
        this.pipeWidth = 50;
        this.gap = 150;
        this.speed = 2;
        this.spawnRate = 90; // frames
        this.frames = 0;
    }

    update() {
        this.frames++;
        if (this.frames % this.spawnRate === 0) {
            this.pipes.push(new Pipe(canvas.width, this.pipeWidth, this.gap));
        }

        for (let i = this.pipes.length - 1; i >= 0; i--) {
            this.pipes[i].update(this.speed);
            if (this.pipes[i].isOffScreen()) {
                this.pipes.splice(i, 1);
            }
        }
    }

    draw(ctx) {
        this.pipes.forEach(pipe => pipe.draw(ctx));
    }

    checkCollisions(bird) {
        for (let pipe of this.pipes) {
            if (pipe.checkCollision(bird)) {
                return true;
            }
        }
        return false;
    }
}