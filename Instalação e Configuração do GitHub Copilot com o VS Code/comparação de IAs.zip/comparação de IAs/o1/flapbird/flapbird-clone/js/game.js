// File: /flapbird-clone/flapbird-clone/js/game.js

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const bird = new Bird();
const pipes = new Pipes();
let score = 0;
let gameOver = false;

function init() {
    document.addEventListener('keydown', handleJump);
    requestAnimationFrame(gameLoop);
}

function handleJump(event) {
    if (event.code === 'Space' && !gameOver) {
        bird.jump();
    }
}

function gameLoop() {
    if (!gameOver) {
        update();
        render();
        requestAnimationFrame(gameLoop);
    } else {
        displayGameOver();
    }
}

function update() {
    bird.update();
    pipes.update();
    checkCollisions();
    score += pipes.scoreIncrement(bird);
}

function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    bird.render(ctx);
    pipes.render(ctx);
    ctx.fillStyle = 'black';
    ctx.font = '20px Arial';
    ctx.fillText(`Score: ${score}`, 10, 20);
}

function checkCollisions() {
    if (bird.y + bird.height >= canvas.height || bird.y <= 0 || pipes.checkCollision(bird)) {
        gameOver = true;
    }
}

function displayGameOver() {
    ctx.fillStyle = 'red';
    ctx.font = '40px Arial';
    ctx.fillText('Game Over', canvas.width / 4, canvas.height / 2);
    ctx.font = '20px Arial';
    ctx.fillText(`Final Score: ${score}`, canvas.width / 3, canvas.height / 2 + 30);
}

init();