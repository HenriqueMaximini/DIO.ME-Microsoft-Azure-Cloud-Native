// File: /roulette-game/roulette-game/src/js/game.js

const canvas = document.getElementById('rouletteCanvas');
const ctx = canvas.getContext('2d');
const spinButton = document.getElementById('spinButton');
const resultDisplay = document.getElementById('result');

let isSpinning = false;
let spinAngle = 0;
let spinDuration = 2000; // 2 seconds
let spinInterval;

function drawWheel() {
    const numSegments = 10;
    const segmentAngle = (2 * Math.PI) / numSegments;

    for (let i = 0; i < numSegments; i++) {
        const startAngle = i * segmentAngle + spinAngle;
        const endAngle = (i + 1) * segmentAngle + spinAngle;

        ctx.beginPath();
        ctx.moveTo(200, 200);
        ctx.arc(200, 200, 150, startAngle, endAngle);
        ctx.fillStyle = `hsl(${(i * 36)}, 100%, 50%)`;
        ctx.fill();
        ctx.stroke();

        ctx.save();
        ctx.translate(200, 200);
        ctx.rotate(startAngle + segmentAngle / 2);
        ctx.fillStyle = 'white';
        ctx.fillText(i + 1, 70, 10);
        ctx.restore();
    }
}

function spinWheel() {
    if (isSpinning) return;

    isSpinning = true;
    spinAngle = 0;
    const randomNumber = Math.floor(Math.random() * 10) + 1;
    const finalAngle = (randomNumber - 1) * (360 / 10) + 360 * 5; // Spin multiple times

    spinInterval = setInterval(() => {
        spinAngle += 10; // Increment angle for animation
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawWheel();
        ctx.save();
        ctx.translate(200, 200);
        ctx.rotate((spinAngle * Math.PI) / 180);
        ctx.drawImage(canvas, -200, -200);
        ctx.restore();
    }, 16); // Approximately 60 frames per second

    setTimeout(() => {
        clearInterval(spinInterval);
        isSpinning = false;
        resultDisplay.innerText = `Result: ${randomNumber}`;
    }, spinDuration);
}

spinButton.addEventListener('click', spinWheel);
drawWheel();