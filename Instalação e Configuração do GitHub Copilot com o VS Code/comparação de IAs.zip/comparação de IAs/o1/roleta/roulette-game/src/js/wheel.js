function drawWheel(ctx, radius) {
    const segments = 10;
    const angle = (2 * Math.PI) / segments;

    for (let i = 0; i < segments; i++) {
        const startAngle = i * angle;
        const endAngle = startAngle + angle;

        // Set color for each segment
        ctx.fillStyle = i % 2 === 0 ? '#FFDD57' : '#FFAA00';
        ctx.beginPath();
        ctx.moveTo(200, 200); // Center of the wheel
        ctx.arc(200, 200, radius, startAngle, endAngle);
        ctx.fill();

        // Draw the number
        ctx.fillStyle = '#000';
        ctx.font = '20px Arial';
        ctx.fillText(i + 1, 200 + (radius / 2) * Math.cos(startAngle + angle / 2) - 10, 
                      200 + (radius / 2) * Math.sin(startAngle + angle / 2) + 10);
    }
}

function spinWheel(canvas, ctx) {
    const spinDuration = Math.random() * 3000 + 2000; // Spin for 2 to 5 seconds
    const startTime = performance.now();
    const spinAngle = Math.random() * 360 + 720; // Random spin angle

    function animate() {
        const currentTime = performance.now();
        const elapsedTime = currentTime - startTime;

        if (elapsedTime < spinDuration) {
            const progress = elapsedTime / spinDuration;
            const angle = spinAngle * easeOutCubic(progress);
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.save();
            ctx.translate(200, 200);
            ctx.rotate((angle * Math.PI) / 180);
            ctx.translate(-200, -200);
            drawWheel(ctx, 150);
            ctx.restore();
            requestAnimationFrame(animate);
        } else {
            const finalAngle = spinAngle % 360;
            const result = Math.floor((finalAngle / 36) % 10) + 1; // Calculate result based on angle
            return result;
        }
    }

    return animate();
}

function easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
}

const canvas = document.getElementById('rouletteCanvas');
const ctx = canvas.getContext('2d');
drawWheel(ctx, 150); // Initial draw of the wheel

document.getElementById('spinButton').addEventListener('click', () => {
    const result = spinWheel(canvas, ctx);
    setTimeout(() => {
        document.getElementById('result').innerText = `Result: ${result}`;
    }, 3000); // Display result after spin duration
});