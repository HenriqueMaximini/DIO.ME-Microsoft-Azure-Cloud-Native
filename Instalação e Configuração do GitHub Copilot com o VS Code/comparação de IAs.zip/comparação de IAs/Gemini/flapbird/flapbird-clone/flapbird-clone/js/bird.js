class Bird {
    constructor(canvas) {
        this.canvas = canvas;
        this.context = canvas.getContext('2d');
        this.x = 50; // Initial horizontal position
        this.y = canvas.height / 2; // Initial vertical position
        this.width = 34; // Width of the bird image
        this.height = 24; // Height of the bird image
        this.gravity = 0.6; // Gravity effect
        this.lift = -10; // Lift effect when flapping
        this.velocity = 0; // Initial velocity
        this.image = new Image();
        this.image.src = 'path/to/bird-image.png'; // Path to the bird image
    }

    flap() {
        this.velocity += this.lift; // Apply lift when flapping
    }

    update() {
        this.velocity += this.gravity; // Apply gravity
        this.y += this.velocity; // Update vertical position

        // Prevent the bird from going off the canvas
        if (this.y + this.height >= this.canvas.height) {
            this.y = this.canvas.height - this.height;
            this.velocity = 0; // Reset velocity if hitting the ground
        }
        if (this.y <= 0) {
            this.y = 0; // Prevent going above the canvas
            this.velocity = 0; // Reset velocity if hitting the top
        }
    }

    render() {
        this.context.drawImage(this.image, this.x, this.y, this.width, this.height); // Draw the bird
    }
}