class Pipe {
    constructor(x, width, gap) {
        this.x = x;
        this.width = width;
        this.gap = gap;
        this.height = Math.floor(Math.random() * (canvas.height - gap));
        this.passed = false; // To check if the bird has passed the pipe
    }

    draw(ctx) {
        // Draw the top pipe
        ctx.fillStyle = 'green';
        ctx.fillRect(this.x, 0, this.width, this.height);
        
        // Draw the bottom pipe
        ctx.fillRect(this.x, this.height + this.gap, this.width, canvas.height - this.height - this.gap);
    }

    update(speed) {
        this.x -= speed;
    }

    isOffScreen() {
        return this.x + this.width < 0;
    }

    checkCollision(bird) {
        // Check for collision with the pipes
        if (bird.x + bird.width > this.x && bird.x < this.x + this.width) {
            if (bird.y < this.height || bird.y + bird.height > this.height + this.gap) {
                return true; // Collision detected
            }
        }
        return false; // No collision
    }

    reset() {
        this.x = canvas.width; // Reset pipe position to the right side of the canvas
        this.height = Math.floor(Math.random() * (canvas.height - this.gap));
        this.passed = false; // Reset passed status
    }
}

class PipeManager {
    constructor() {
        this.pipes = [];
        this.pipeWidth = 50;
        this.gap = 150;
        this.speed = 3;
        this.spawnRate = 90; // Frames until a new pipe is spawned
        this.frames = 0;
    }

    update() {
        this.frames++;
        if (this.frames % this.spawnRate === 0) {
            this.pipes.push(new Pipe(canvas.width, this.pipeWidth, this.gap));
        }

        for (let i = this.pipes.length - 1; i >= 0; i--) {
            const pipe = this.pipes[i];
            pipe.update(this.speed);
            if (pipe.isOffScreen()) {
                this.pipes.splice(i, 1); // Remove off-screen pipes
            }
        }
    }

    draw(ctx) {
        this.pipes.forEach(pipe => pipe.draw(ctx));
    }

    checkCollisions(bird) {
        for (let pipe of this.pipes) {
            if (pipe.checkCollision(bird)) {
                return true; // Collision detected
            }
        }
        return false; // No collision
    }
}