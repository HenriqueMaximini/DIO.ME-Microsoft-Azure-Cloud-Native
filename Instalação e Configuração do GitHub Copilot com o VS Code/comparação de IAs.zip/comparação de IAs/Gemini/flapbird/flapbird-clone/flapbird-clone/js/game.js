// File: /flapbird-clone/flapbird-clone/flapbird-clone/js/game.js

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let bird;
let pipes = [];
let score = 0;
let gameOver = false;

function init() {
    bird = new Bird();
    pipes = [];
    score = 0;
    gameOver = false;
    requestAnimationFrame(gameLoop);
}

function gameLoop() {
    if (gameOver) {
        return;
    }
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    bird.update();
    bird.draw();
    
    if (frames % 100 === 0) {
        pipes.push(new Pipe());
    }
    
    pipes.forEach((pipe, index) => {
        pipe.update();
        pipe.draw();
        
        if (pipe.x + pipe.width < 0) {
            pipes.splice(index, 1);
            score++;
        }
        
        if (pipe.collidesWith(bird)) {
            gameOver = true;
            alert('Game Over! Your score: ' + score);
            init();
        }
    });
    
    ctx.fillStyle = 'black';
    ctx.font = '20px Arial';
    ctx.fillText('Score: ' + score, 10, 20);
    
    frames++;
    requestAnimationFrame(gameLoop);
}

document.getElementById('startButton').addEventListener('click', init);
document.addEventListener('keydown', (event) => {
    if (event.code === 'Space' && !gameOver) {
        bird.flap();
    }
});

let frames = 0;