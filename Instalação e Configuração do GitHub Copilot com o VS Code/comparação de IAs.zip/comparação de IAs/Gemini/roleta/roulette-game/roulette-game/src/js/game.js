// src/js/game.js

const spinButton = document.getElementById('spinButton');
const resultDiv = document.getElementById('result');
const canvas = document.getElementById('rouletteCanvas');
const ctx = canvas.getContext('2d');

const segments = 10;
const anglePerSegment = (2 * Math.PI) / segments;

function drawWheel() {
    for (let i = 0; i < segments; i++) {
        const angle = i * anglePerSegment;
        ctx.beginPath();
        ctx.moveTo(200, 200);
        ctx.arc(200, 200, 150, angle, angle + anglePerSegment);
        ctx.fillStyle = i % 2 === 0 ? '#FFCC00' : '#FF9900';
        ctx.fill();
        ctx.stroke();
        
        ctx.save();
        ctx.translate(200, 200);
        ctx.rotate(angle + anglePerSegment / 2);
        ctx.fillStyle = '#000';
        ctx.fillText(i + 1, 60, 10);
        ctx.restore();
    }
}

function spinWheel() {
    const randomNumber = Math.floor(Math.random() * segments) + 1;
    const spinDuration = 2000; // 2 seconds
    const spinAngle = (Math.random() * 360) + (randomNumber - 1) * (360 / segments);
    
    let startTime = null;

    function animateSpin(timestamp) {
        if (!startTime) startTime = timestamp;
        const elapsed = timestamp - startTime;

        const currentAngle = spinAngle * (elapsed / spinDuration);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawWheel();
        ctx.save();
        ctx.translate(200, 200);
        ctx.rotate((currentAngle * Math.PI) / 180);
        ctx.drawImage(canvas, -200, -200);
        ctx.restore();

        if (elapsed < spinDuration) {
            requestAnimationFrame(animateSpin);
        } else {
            resultDiv.innerText = `Result: ${randomNumber}`;
        }
    }

    requestAnimationFrame(animateSpin);
}

spinButton.addEventListener('click', spinWheel);
drawWheel();