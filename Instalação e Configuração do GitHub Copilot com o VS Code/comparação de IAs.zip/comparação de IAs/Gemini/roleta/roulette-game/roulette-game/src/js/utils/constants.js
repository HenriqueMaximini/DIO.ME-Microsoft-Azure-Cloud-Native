// This file exports constants used throughout the project.

const NUM_SEGMENTS = 10;
const SEGMENT_ANGLE = 360 / NUM_SEGMENTS;
const COLORS = [
    '#FF5733', // Color for segment 1
    '#33FF57', // Color for segment 2
    '#3357FF', // Color for segment 3
    '#F1C40F', // Color for segment 4
    '#8E44AD', // Color for segment 5
    '#E67E22', // Color for segment 6
    '#2ECC71', // Color for segment 7
    '#3498DB', // Color for segment 8
    '#9B59B6', // Color for segment 9
    '#E74C3C'  // Color for segment 10
];

export { NUM_SEGMENTS, SEGMENT_ANGLE, COLORS };