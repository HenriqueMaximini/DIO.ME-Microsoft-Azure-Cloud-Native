// filepath: roulette-game/roulette-game/src/js/wheel.js

const canvas = document.getElementById('rouletteCanvas');
const ctx = canvas.getContext('2d');

const segments = 10; // Number of segments on the wheel
const angle = (2 * Math.PI) / segments; // Angle for each segment
const colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#FFBD33', '#33FFF5', '#FF33D4', '#A133FF', '#33FF8C', '#FF3333'];

function drawWheel() {
    for (let i = 0; i < segments; i++) {
        ctx.beginPath();
        ctx.moveTo(200, 200); // Center of the wheel
        ctx.arc(200, 200, 150, i * angle, (i + 1) * angle);
        ctx.fillStyle = colors[i % colors.length];
        ctx.fill();
        ctx.stroke();
        
        // Draw the segment number
        ctx.save();
        ctx.translate(200, 200);
        ctx.rotate(i * angle + angle / 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '20px Arial';
        ctx.fillText(i + 1, 70, 10);
        ctx.restore();
    }
}

function spinWheel() {
    const randomSpin = Math.floor(Math.random() * 360 + 720); // Random spin between 720 and 1080 degrees
    const spinDuration = 2000; // Spin duration in milliseconds
    const startTime = performance.now();

    function animateSpin(currentTime) {
        const elapsedTime = currentTime - startTime;
        const progress = Math.min(elapsedTime / spinDuration, 1);
        const rotation = progress * randomSpin;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.save();
        ctx.translate(200, 200);
        ctx.rotate((rotation * Math.PI) / 180);
        ctx.translate(-200, -200);
        drawWheel();
        ctx.restore();

        if (progress < 1) {
            requestAnimationFrame(animateSpin);
        } else {
            const result = Math.floor(((rotation % 360) / 360) * segments) + 1; // Calculate the result segment
            displayResult(result);
        }
    }

    requestAnimationFrame(animateSpin);
}

function displayResult(result) {
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `Result: ${result}`;
}

document.getElementById('spinButton').addEventListener('click', spinWheel);
drawWheel();