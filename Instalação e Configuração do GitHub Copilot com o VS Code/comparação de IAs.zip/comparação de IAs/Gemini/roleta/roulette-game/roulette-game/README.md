# Roulette Game

## Overview
This project is a simple and visually appealing roulette game that allows users to spin a wheel numbered from 1 to 10. The wheel spins randomly every 2 seconds and lands on a random number, providing an engaging experience.

## Project Structure
```
roulette-game
└── roulette-game
    ├── src
    │   ├── index.html        # Main HTML document for the roulette game
    │   ├── css
    │   │   └── styles.css    # CSS styles for the game
    │   ├── js
    │   │   ├── game.js       # Main game logic
    │   │   ├── wheel.js      # Functionality for the roulette wheel
    │   │   └── utils
    │   │       └── constants.js # Constants used throughout the project
    ├── package.json          # npm configuration file
    └── README.md             # Project documentation
```

## Getting Started

### Prerequisites
- Node.js and npm installed on your machine.

### Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd roulette-game/roulette-game
   ```
3. Install dependencies (if any):
   ```
   npm install
   ```

### Running the Game
1. Open `src/index.html` in your web browser.
2. Click the "Spin the Wheel" button to start the game.

## Features
- A visually appealing roulette wheel with segments numbered from 1 to 10.
- The wheel spins every 2 seconds and lands on a random number.
- Simple and intuitive user interface.

## Contributing
Feel free to submit issues or pull requests if you have suggestions for improvements or new features.

## License
This project is licensed under the MIT License.