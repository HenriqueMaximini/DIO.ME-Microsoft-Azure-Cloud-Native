function checkCollision(bird, pipes) {
    for (let i = 0; i < pipes.length; i++) {
        const pipe = pipes[i];

        // Check if the bird is within the horizontal bounds of the pipe
        if (bird.x + bird.width > pipe.x && bird.x < pipe.x + pipe.width) {
            // Check if the bird is within the vertical bounds of the pipe
            if (bird.y < pipe.topHeight || bird.y + bird.height > pipe.topHeight + pipe.gap) {
                return true; // Collision detected
            }
        }
    }
    return false; // No collision
}

function isOutOfBounds(bird, canvasHeight) {
    return bird.y + bird.height >= canvasHeight || bird.y <= 0; // Check if the bird is out of the canvas bounds
}

export { checkCollision, isOutOfBounds };