// Game.js - Main game logic for Flap Bird Clone

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let bird;
let pipes = [];
let score = 0;
let gameInterval;
let isGameOver = false;

function init() {
    bird = new Bird(canvas.width / 4, canvas.height / 2);
    pipes = [];
    score = 0;
    isGameOver = false;
    gameLoop();
}

function gameLoop() {
    if (isGameOver) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    bird.update();
    bird.draw();

    if (frameCount % 90 === 0) {
        pipes.push(new Pipes(canvas.width, Math.random() * (canvas.height - 200) + 50));
    }

    pipes.forEach((pipe, index) => {
        pipe.update();
        pipe.draw();

        if (pipe.offScreen()) {
            pipes.splice(index, 1);
            score++;
        }

        if (collision(bird, pipe)) {
            endGame();
        }
    });

    ctx.fillStyle = 'black';
    ctx.font = '20px Arial';
    ctx.fillText(`Score: ${score}`, 10, 20);

    frameCount++;
    requestAnimationFrame(gameLoop);
}

function endGame() {
    isGameOver = true;
    ctx.fillStyle = 'red';
    ctx.font = '40px Arial';
    ctx.fillText('Game Over', canvas.width / 4, canvas.height / 2);
}

document.getElementById('startButton').addEventListener('click', init);

let frameCount = 0;