class Pipe {
    constructor(x, width, gap) {
        this.x = x;
        this.width = width;
        this.gap = gap;
        this.height = Math.floor(Math.random() * (400 - gap)) + 20; // Random height for the top pipe
        this.passed = false; // To check if the bird has passed the pipe
    }

    draw(ctx) {
        // Draw the top pipe
        ctx.fillStyle = 'green';
        ctx.fillRect(this.x, 0, this.width, this.height);
        // Draw the bottom pipe
        ctx.fillRect(this.x, this.height + this.gap, this.width, ctx.canvas.height - this.height - this.gap);
    }

    update(speed) {
        this.x -= speed; // Move the pipe to the left
    }

    isOffScreen() {
        return this.x + this.width < 0; // Check if the pipe is off the screen
    }

    checkPass(bird) {
        if (!this.passed && bird.x > this.x + this.width) {
            this.passed = true; // Mark as passed
            return true; // Bird passed the pipe
        }
        return false; // Bird has not passed the pipe
    }
}

class PipeManager {
    constructor() {
        this.pipes = [];
        this.pipeWidth = 50;
        this.gap = 150;
        this.speed = 2;
        this.spawnRate = 90; // Frames until a new pipe is spawned
        this.frames = 0;
    }

    update() {
        this.frames++;
        if (this.frames % this.spawnRate === 0) {
            this.pipes.push(new Pipe(canvas.width, this.pipeWidth, this.gap));
        }

        this.pipes.forEach(pipe => {
            pipe.update(this.speed);
        });

        // Remove off-screen pipes
        this.pipes = this.pipes.filter(pipe => !pipe.isOffScreen());
    }

    draw(ctx) {
        this.pipes.forEach(pipe => {
            pipe.draw(ctx);
        });
    }

    checkCollisions(bird) {
        for (let pipe of this.pipes) {
            if (bird.x < pipe.x + pipe.width && bird.x + bird.width > pipe.x) {
                if (bird.y < pipe.height || bird.y + bird.height > pipe.height + pipe.gap) {
                    return true; // Collision detected
                }
            }
        }
        return false; // No collision
    }

    checkPass(bird) {
        let score = 0;
        this.pipes.forEach(pipe => {
            if (pipe.checkPass(bird)) {
                score++;
            }
        });
        return score; // Return the score for passing pipes
    }
}

export { PipeManager };