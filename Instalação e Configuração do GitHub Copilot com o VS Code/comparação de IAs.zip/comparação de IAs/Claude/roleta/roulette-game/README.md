# Roulette Game

This project is a visually appealing and functional roulette game built using HTML, CSS, and JavaScript with Canvas. The game features a spinning roulette wheel with numbered areas from 1 to 10, and it randomly lands on a number every 2 seconds.

## Project Structure

```
roulette-game
├── src
│   ├── index.html        # Main HTML document for the roulette game
│   ├── css
│   │   └── styles.css    # Styles for the roulette game
│   └── js
│       ├── game.js       # Main logic for the roulette game
│       └── wheel.js      # Handles drawing and spinning of the roulette wheel
├── package.json          # Configuration file for npm
└── README.md             # Documentation for the project
```

## Features

- A roulette wheel with numbered sections from 1 to 10.
- The wheel spins randomly every 2 seconds.
- The game determines and displays the winning number after each spin.

## Getting Started

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd roulette-game
   ```

3. Open `src/index.html` in your web browser to play the game.

## Dependencies

This project does not have any external dependencies. It uses vanilla JavaScript for functionality.

## License

This project is licensed under the MIT License.