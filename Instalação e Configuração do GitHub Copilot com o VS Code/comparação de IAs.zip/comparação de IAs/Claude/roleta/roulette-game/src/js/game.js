// This file contains the main logic for the roulette game.

const canvas = document.getElementById('rouletteCanvas');
const ctx = canvas.getContext('2d');
const spinButton = document.getElementById('spinButton');
const resultDisplay = document.getElementById('resultDisplay');

let isSpinning = false;
let spinAngle = 0;
let spinDuration = 2000; // 2 seconds
let winningNumber = null;

function drawWheel() {
    const numSections = 10;
    const sectionAngle = (2 * Math.PI) / numSections;

    for (let i = 0; i < numSections; i++) {
        const startAngle = i * sectionAngle + spinAngle;
        const endAngle = startAngle + sectionAngle;

        ctx.beginPath();
        ctx.moveTo(canvas.width / 2, canvas.height / 2);
        ctx.arc(canvas.width / 2, canvas.height / 2, 150, startAngle, endAngle);
        ctx.fillStyle = i % 2 === 0 ? '#FFDD57' : '#FF5733';
        ctx.fill();
        ctx.stroke();

        // Draw the number
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(startAngle + sectionAngle / 2);
        ctx.fillStyle = '#000';
        ctx.font = '20px Arial';
        ctx.fillText(i + 1, 60, 10);
        ctx.restore();
    }
}

function spinWheel() {
    if (isSpinning) return;

    isSpinning = true;
    spinAngle = 0;
    winningNumber = Math.floor(Math.random() * 10) + 1;

    const spinInterval = setInterval(() => {
        spinAngle += 0.1; // Adjust the speed of the spin
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawWheel();
    }, 16); // Approximately 60 frames per second

    setTimeout(() => {
        clearInterval(spinInterval);
        isSpinning = false;
        resultDisplay.textContent = `Winning Number: ${winningNumber}`;
    }, spinDuration);
}

spinButton.addEventListener('click', spinWheel);
drawWheel();