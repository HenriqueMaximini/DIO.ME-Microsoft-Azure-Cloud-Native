function drawWheel(ctx, radius) {
    const numSections = 10;
    const sectionAngle = (2 * Math.PI) / numSections;

    for (let i = 0; i < numSections; i++) {
        const startAngle = i * sectionAngle;
        const endAngle = startAngle + sectionAngle;

        // Set the fill color based on the section number
        ctx.fillStyle = i % 2 === 0 ? '#FFDD00' : '#FFAA00';
        ctx.beginPath();
        ctx.arc(0, 0, radius, startAngle, endAngle);
        ctx.lineTo(0, 0);
        ctx.fill();

        // Draw the section number
        ctx.fillStyle = '#000';
        ctx.font = 'bold 20px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const midAngle = startAngle + sectionAngle / 2;
        const x = (radius / 2) * Math.cos(midAngle);
        const y = (radius / 2) * Math.sin(midAngle);
        ctx.fillText(i + 1, x, y);
    }
}

function spinWheel(ctx, radius) {
    const spinDuration = 2000; // 2 seconds
    const startTime = performance.now();

    function animate(time) {
        const elapsed = time - startTime;
        const progress = Math.min(elapsed / spinDuration, 1);
        const angle = progress * (Math.PI * 4 + Math.random() * Math.PI * 2); // Random spin

        ctx.clearRect(-radius, -radius, radius * 2, radius * 2);
        ctx.save();
        ctx.rotate(angle);
        drawWheel(ctx, radius);
        ctx.restore();

        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            const winningNumber = Math.floor((angle / (2 * Math.PI)) * 10) % 10 + 1;
            console.log(`Winning Number: ${winningNumber}`);
        }
    }

    requestAnimationFrame(animate);
}

function setupCanvas() {
    const canvas = document.getElementById('rouletteCanvas');
    const ctx = canvas.getContext('2d');
    const radius = Math.min(canvas.width, canvas.height) / 2 - 10;

    ctx.translate(canvas.width / 2, canvas.height / 2);
    drawWheel(ctx, radius);

    return { ctx, radius };
}

document.addEventListener('DOMContentLoaded', () => {
    const { ctx, radius } = setupCanvas();
    const spinButton = document.getElementById('spinButton');

    spinButton.addEventListener('click', () => {
        spinWheel(ctx, radius);
    });
});