class CepController {
    constructor(viaCepService) {
        this.viaCepService = viaCepService;
    }

    async getAddressByCep(req, res) {
        const { cep } = req.params;

        try {
            const address = await this.viaCepService.fetchAddress(cep);
            if (!address) {
                return res.status(404).json({ error: 'Address not found' });
            }
            res.json(address);
        } catch (error) {
            res.status(500).json({ error: 'An error occurred while fetching the address' });
        }
    }
}

export default CepController;