# Via CEP API

This project is a simple Node.js API that utilizes the Via CEP service to return address information in JSON format based on a provided postal code (CEP).

## Features

- Fetch address information using a postal code (CEP).
- Returns data in JSON format.
- Simple and easy-to-use API for developers.

## Technologies Used

- Node.js
- Express
- Axios

## Getting Started

### Prerequisites

- Node.js installed on your machine.
- npm (Node Package Manager).

### Installation

1. Clone the repository:

   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:

   ```
   cd via-cep-api
   ```

3. Install the dependencies:

   ```
   npm install
   ```

### Running the API

To start the server, run the following command:

```
npm start
```

The API will be running on `http://localhost:3000`.

### API Endpoint

- **GET** `/cep/:cep`

  Replace `:cep` with the postal code you want to look up. For example:

  ```
  GET http://localhost:3000/cep/01001-000
  ```

### Example Response

```json
{
  "cep": "01001-000",
  "logradouro": "Praça da Sé",
  "complemento": "lado ímpar",
  "bairro": "Sé",
  "localidade": "São Paulo",
  "uf": "SP",
  "ibge": "3550308",
  "gia": "1004",
  "ddd": "11",
  "siafi": "7087"
}
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request.

## License

This project is licensed under the MIT License.